package trabalhoFinal;

public class Descanso implements Timer{
	public String descanso(){
		return "Descansando\n";
	}
	public String descansoSugerido(float tempoGasto){
		return "Tempo Sugerido\n"+tempoGasto;
	}
	public String parcialDescanso(float tempoGasto){
		return "Parcial Descanso\n"+tempoGasto;
	}
	public String totalDescanso(float tempoGasto){
		return "Total Descanso\n"+tempoGasto;
	}
}