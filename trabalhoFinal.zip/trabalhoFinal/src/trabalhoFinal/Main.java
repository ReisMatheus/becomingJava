package trabalhoFinal;
import java.util.concurrent.TimeUnit;
import java.util
import org.apache.commons.lang3.time.*;

public class Main{

	public static void main(String[] args){
		StopWatch count = new StopWatch();
		TimeUnit minutos = TimeUnit.MINUTES;
		count.start();
		long time = count.getTime(minutos);

	}

}
