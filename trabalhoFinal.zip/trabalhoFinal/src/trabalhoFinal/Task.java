package trabalhoFinal;

public class Task {

	public Task() {
		// TODO Auto-generated constructor stub
	}

}
