package trabalhoFinal;

public interface Timer{
	public String descanso();
	public String descansoSugerido(float tempoGasto);
	public String parcialDescanso(float tempoGasto);
	public String totalDescanso(float tempoGasto);
}
